/*
** param.h for Corewar in /home/guiho_r//tek1/corewar/include
** 
** Made by ronan guiho
** Login   <guiho_r@epitech.net>
** 
** Started on  Fri Jan 27 13:36:03 2012 ronan guiho
** Last update Sun Mar 18 13:10:09 2012 alexis leprovost
*/

#ifndef	__PARAM_H__
#define __PARAM_H__

typedef struct s_param
{
  int	rand_mem;
  int	rand_reg;
  int	dump;
  int	nbr_live;
} t_param;

#endif
