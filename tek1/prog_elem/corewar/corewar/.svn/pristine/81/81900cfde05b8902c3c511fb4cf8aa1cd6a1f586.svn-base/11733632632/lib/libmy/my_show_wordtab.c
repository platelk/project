/*
** my_show_wordtab.c for my_show_wordtab in /home/platel_k//projet/piscine/Jour_08/ex_05
** 
** Made by kevin platel
** Login   <platel_k@epitech.net>
** 
** Started on  Wed Oct 12 20:10:13 2011 kevin platel
** Last update Wed Nov 23 11:08:00 2011 kevin platel
*/

#include "my.h"

int	my_show_wordtab(char **wordtab)
{
  int	i;

  i = 0;
  while (wordtab[i] != 0)
    {
      my_putstr(wordtab[i]);
      my_putchar('\n');
      i = i + 1;
    }
  return (0);
}
