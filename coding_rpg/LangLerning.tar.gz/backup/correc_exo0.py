#!/usr/bin/python3.3

while i < 5:
    print("salut")
    i += 1