#!/usr/bin/python3.3

def     test(a, b):
    print(a)
    print(b)

l = [5,3]
test(*l)