/*
** check_base.c for check_base in /home/leprov_a//bdd/source/ps
** 
** Made by alexis leprovost
** Login   <leprov_a@epitech.net>
** 
** Started on  Mon Jan 16 12:43:47 2012 alexis leprovost
** Last update Sat Jan 21 20:35:18 2012 alexis leprovost
*/

#include	"my.h"

int	check_base(char c, char *bdd)
{
  int i;

  i = 0;
  while (bdd[i] != c && bdd[i] != '\0')
    i++;
  if (bdd[i] == '\0')
    return (EXIT_FAILURE);
  return (EXIT_SUCCESS);
}
