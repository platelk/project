/*
** data_champ.h for Corewar in /home/guiho_r//tek1/corewar/include
** 
** Made by ronan guiho
** Login   <guiho_r@epitech.net>
** 
** Started on  Fri Jan 27 13:38:34 2012 ronan guiho
** Last update Fri Feb  3 18:55:14 2012 ronan guiho
*/

#ifndef __DATA_CHAMP_H__
#define __DATA_CHAMP_H__

typedef struct s_data_champ
{
  int	id;
  int	addr;
  char	*name;
  struct s_data_champ *next;
} t_data_champ;

#endif
