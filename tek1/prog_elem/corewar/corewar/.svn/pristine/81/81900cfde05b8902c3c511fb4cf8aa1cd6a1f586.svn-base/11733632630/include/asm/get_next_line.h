/*
** get_next_line.h for get_next_lin in /home/platel_k/projet/get_next_line
** 
** Made by kevin platel
** Login   <platel_k@epitech.net>
** 
** Started on  Mon Nov 14 14:01:31 2011 kevin platel
** Last update Thu Mar 22 14:27:16 2012 alexandre deceneux
*/

#ifndef __GET_NEXT_LINE__
#define __GET_NEXT_LINE__

#define BUFFER_SIZE	(1024)
#define READ_SIZE	(1)

char		*get_next_line(const int fd, int *l);

#endif
