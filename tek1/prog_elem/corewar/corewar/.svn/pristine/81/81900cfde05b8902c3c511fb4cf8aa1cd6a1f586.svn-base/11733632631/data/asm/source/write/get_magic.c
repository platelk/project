/*
** get_magic.c for get_magic in /home/vink/projet/prog_elem/corewar/corewar
** 
** Made by kevin platel
** Login   <platel_k@epitech.net>
** 
** Started on  Wed Feb 22 14:19:44 2012 kevin platel
** Last update Tue Mar 13 10:09:42 2012 kevin platel
*/

#include "op.h"
#include "corewar.h"

int	magic(int nbr)
{
  t_str_int	tmp;
  t_str_int	tmp2;

  tmp.value = nbr;
  tmp2.str[0] = tmp.str[3];
  tmp2.str[1] = tmp.str[2];
  tmp2.str[2] = tmp.str[1];
  tmp2.str[3] = tmp.str[0];
  return (tmp2.value);
}
