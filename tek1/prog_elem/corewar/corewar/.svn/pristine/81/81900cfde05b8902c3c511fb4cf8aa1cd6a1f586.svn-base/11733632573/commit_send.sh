#!/bin/bash
## commit_send.sh for Commit in /home/guiho_r//tek1/corewar
## 
## Made by ronan guiho
## Login   <guiho_r@epitech.net>
## 
## Started on  Tue Jan 24 13:52:28 2012 ronan guiho
## Last update Tue Jan 24 13:56:33 2012 ronan guiho
##

echo -n "Message : "
read message
svn commit -m "$message"
ns_send_msg leprov_a "New REV : $message"
ns_send_msg guiho_r  "New REV : $message"
ns_send_msg platel_k "New REV : $message"
ns_send_msg decene_a "New REV : $message"
