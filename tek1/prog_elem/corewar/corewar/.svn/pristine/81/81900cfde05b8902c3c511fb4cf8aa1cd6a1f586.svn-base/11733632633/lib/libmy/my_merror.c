/*
** my_errorm.c for my_errorm in /home/leprov_a//project/igraph/wolf3d/v_05/src/tool
** 
** Made by alexis leprovost
** Login   <leprov_a@epitech.net>
** 
** Started on  Sat Jan 14 19:55:10 2012 alexis leprovost
** Last update Thu Jan 19 19:19:11 2012 alexis leprovost
*/

#include	<stdlib.h>

#include	"my.h"

void	my_merror(void)
{
  my_puterror(SYNTAX_MSG_ERROR);
  my_puterror(": Could not alloc.\n");
  exit(EXIT_FAILURE);
}
