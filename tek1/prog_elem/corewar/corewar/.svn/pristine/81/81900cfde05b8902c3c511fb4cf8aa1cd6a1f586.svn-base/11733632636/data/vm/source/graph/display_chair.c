/*
** display_chair.c for corewar in /home/guiho_r/tek1/corewar/data/VM/source/graph
** 
** Made by ronan guiho
** Login   <guiho_r@epitech.net>
** 
** Started on  Wed Mar 14 13:35:55 2012 ronan guiho
** Last update Sun Mar 18 18:13:44 2012 ronan guiho
*/

#include <stdlib.h>

#include "vm.h"
#include "corewar.h"

void	display_chair(t_vm *vm)
{
  vm->image[GAME][CHAIR].pos.x = 250;
  vm->image[GAME][CHAIR].pos.y = 775;
  SDL_BlitSurface(vm->image[GAME][CHAIR].img, NULL, vm->sc,
		  &vm->image[GAME][CHAIR].pos);
  vm->image[GAME][CHAIR].pos.x = 570;
  vm->image[GAME][CHAIR].pos.y = 775;
  SDL_BlitSurface(vm->image[GAME][CHAIR].img, NULL, vm->sc,
		  &vm->image[GAME][CHAIR].pos);
  vm->image[GAME][CHAIR].pos.x = 822;
  vm->image[GAME][CHAIR].pos.y = 775;
  SDL_BlitSurface(vm->image[GAME][CHAIR].img, NULL, vm->sc,
		  &vm->image[GAME][CHAIR].pos);
  vm->image[GAME][CHAIR].pos.x = 1130;
  vm->image[GAME][CHAIR].pos.y = 775;
  SDL_BlitSurface(vm->image[GAME][CHAIR].img, NULL, vm->sc,
		  &vm->image[GAME][CHAIR].pos);
}
