/*
** my_tablen.c for my_tablen.c in /home/leprov_a//bdd/source/my
** 
** Made by alexis leprovost
** Login   <leprov_a@epitech.net>
** 
** Started on  Tue Dec 27 17:54:31 2011 alexis leprovost
** Last update Thu Jan 19 18:50:11 2012 alexis leprovost
*/

#include	<stdlib.h>

int	my_tablen(char **tab)
{
  int i;

  i = 0;
  if (tab == NULL)
    return (0);
  while (tab[i])
    i++;
  return (i);
}
