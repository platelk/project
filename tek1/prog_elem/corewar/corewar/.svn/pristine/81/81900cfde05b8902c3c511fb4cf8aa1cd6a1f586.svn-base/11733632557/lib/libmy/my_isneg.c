/*
** my_is_neg.c for my_is_neg in /home/platel_k//lib/c
** 
** Made by kevin platel
** Login   <platel_k@epitech.net>
** 
** Started on  Sun Oct 30 04:58:30 2011 kevin platel
** Last update Sun Oct 30 04:59:07 2011 kevin platel
*/

int	my_is_neg(int nb)
{
  if (nb < 0)
    return (0);
  return (1);
}
