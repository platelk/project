/*
** get_rand_number.c for Corewar in /home/guiho_r//tek1/corewar/source/VM/struct
** 
** Made by ronan guiho
** Login   <guiho_r@epitech.net>
** 
** Started on  Fri Feb  3 11:08:02 2012 ronan guiho
** Last update Fri Feb  3 11:08:45 2012 ronan guiho
*/

#include <stdlib.h>

int	get_rand_number(int max)
{
  return (rand() % max);
}
