/*
** my_swap.c for my_swap in /home/platel_k//projet/piscine/Jour_04
** 
** Made by kevin platel
** Login   <platel_k@epitech.net>
** 
** Started on  Thu Oct  6 09:47:04 2011 kevin platel
** Last update Wed Nov 23 11:16:01 2011 kevin platel
*/

#include "my.h"

int	my_swap(int *a, int *b)
{
  int	c;

  c = *a;
  *a = *b;
  *b =  c;

  return (0);
}

char	my_swap_char(char *a, char *b)
{
  char	c;

  c = a[0];
  a[0] = b[0];
  b[0] = c;

  return (0);
}
